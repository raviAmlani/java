
agent_util sources: @(#)README.txt	1.2 04/06/16

Just some shared generic source used by several of the demos.

